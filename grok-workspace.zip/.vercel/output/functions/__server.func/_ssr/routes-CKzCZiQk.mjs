import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ChevronDown, r as Menu, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CKzCZiQk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AboutSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		id: "about",
		"aria-labelledby": "about-title",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wrap",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "02 — About"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "about-title",
					className: "section-title",
					children: "A practice between the newsroom and the product team."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "about-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
					className: "pull",
					children: "“Most interfaces shout. I would rather they hold still long enough to be read.”"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "prose",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I’m Elise Maren, a designer and engineer in Lisbon. I started laying out newspapers, moved into product, and now work on my own — usually with teams of one to six." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A typical engagement is a system: the type, the components, and the code that keeps them honest. I stay through the build. I don’t hand off a deck and disappear." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Right now I’m drawing passenger information for a coastal line and a seasonal catalog for a small press. Two projects a season is the limit, on purpose." })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "facts",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Studio" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Solo, with a short list of collaborators" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Clients" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Workshops, presses, civic teams, small companies" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Method" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Figma for structure. The browser for the truth." })] })
					]
				})] })]
			})]
		})
	});
}
var NAV = [
	{
		href: "#work",
		id: "work",
		label: "Work"
	},
	{
		href: "#about",
		id: "about",
		label: "About"
	},
	{
		href: "#skills",
		id: "skills",
		label: "Skills"
	},
	{
		href: "#contact",
		id: "contact",
		label: "Contact"
	}
];
var FILTERS = [
	"All",
	"Product",
	"Brand",
	"Web"
];
var PROJECTS = [
	{
		id: "northline",
		index: "01",
		title: "Northline",
		category: "Product",
		year: "2025",
		role: "Wayfinding & passenger app",
		summary: "A quieter system for a coastal railway: station type, platform signs, and a passenger app that speaks softly.",
		image: "/work/northline.jpg",
		alt: "Fog over a timber railway platform at dawn, with a single green signal lamp",
		featured: true
	},
	{
		id: "vale",
		index: "02",
		title: "Atelier Vale",
		category: "Brand",
		year: "2024",
		role: "Identity & catalog",
		summary: "Identity for a ceramics workshop — a wordmark, clay-stained packaging, and a catalog that reads like a kiln log.",
		image: "/work/vale.jpg",
		alt: "Unglazed ceramic bowls arranged on linen in soft north light"
	},
	{
		id: "field",
		index: "03",
		title: "Field Notes",
		category: "Web",
		year: "2025",
		role: "Editorial journal",
		summary: "An online journal for naturalists. Long essays, a specimen index, and a reading pace borrowed from print.",
		image: "/work/field.jpg",
		alt: "An open field journal and a fern resting on damp moss"
	},
	{
		id: "harbor",
		index: "04",
		title: "Harbor Ledger",
		category: "Product",
		year: "2024",
		role: "Operations product",
		summary: "A ledger for a cooperative port. Berths, tides, and invoices share one calm surface instead of five tools.",
		image: "/work/harbor.jpg",
		alt: "A small harbor with timber docks at blue hour"
	},
	{
		id: "press",
		index: "05",
		title: "Kinfolk Press",
		category: "Brand",
		year: "2023",
		role: "Specimen & seasonal catalog",
		summary: "A specimen site and seasonal catalog for an independent letterpress, set with the patience of a colophon.",
		image: "/work/press.jpg",
		alt: "Oak type drawers, a brayer, and blank cotton paper in warm workshop light"
	},
	{
		id: "salt",
		index: "06",
		title: "Salt & Index",
		category: "Web",
		year: "2023",
		role: "Cookbook archive",
		summary: "A cookbook archive organized by ingredient, season, and the people who actually cook the dishes.",
		image: "/work/salt.jpg",
		alt: "Flaky salt, olive oil, and thyme on a pale stone counter"
	}
];
var SKILL_GROUPS = [
	{
		title: "Interface",
		note: "How a thing looks when someone is trying to use it.",
		items: [
			["Type systems", "Scales, pairing, and the rules between them"],
			["Product design", "Flows, states, and the unglamorous edges"],
			["Art direction", "Photography, crop, and sequence"],
			["Prototypes", "Clickable enough to argue with"]
		]
	},
	{
		title: "Engineering",
		note: "The same decisions, kept honest in code.",
		items: [
			["React & TypeScript", "Interfaces I can still maintain next year"],
			["Accessibility", "Keyboard, contrast, names that make sense"],
			["Motion", "Short, physical, and easy to turn off"],
			["Design systems", "Tokens that survive a second product"]
		]
	},
	{
		title: "Craft",
		note: "The slower habits that hold the rest together.",
		items: [
			["Editorial layout", "Grids, captions, and pace"],
			["Identity", "Marks, voice, and the small applications"],
			["Writing", "Interface language that sounds like a person"],
			["Research", "A few interviews, then a point of view"]
		]
	}
];
var INTENTS = [
	"Product",
	"Identity",
	"Website",
	"Not sure yet"
];
var EMPTY = {
	name: "",
	email: "",
	intent: "",
	message: ""
};
function validate(values) {
	const errors = {};
	if (values.name.trim().length < 2) errors.name = "Please add your name.";
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) errors.email = "That email doesn’t look right.";
	if (!values.intent) errors.intent = "Choose what you need.";
	if (values.message.trim().length < 20) errors.message = "Give me a sentence or two — at least 20 characters.";
	return errors;
}
function ContactSection() {
	const [values, setValues] = (0, import_react.useState)(EMPTY);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [shake, setShake] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("idle");
	function update(key, value) {
		setValues((current) => ({
			...current,
			[key]: value
		}));
		setErrors((current) => ({
			...current,
			[key]: void 0
		}));
	}
	function onSubmit(event) {
		event.preventDefault();
		const next = validate(values);
		setErrors(next);
		if (Object.keys(next).length > 0) {
			setShake(true);
			window.setTimeout(() => setShake(false), 250);
			const first = Object.keys(next)[0];
			const node = document.getElementById(first);
			if (node instanceof HTMLElement) node.focus();
			return;
		}
		setStatus("sending");
		window.setTimeout(() => setStatus("sent"), 600);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		id: "contact",
		"aria-labelledby": "contact-title",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wrap",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "04 — Contact"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "contact-title",
					className: "section-title",
					children: "Tell me what you’re making."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "contact-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "contact-aside",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A short note is enough. I read everything and reply within two working days. If the timing is wrong, I’ll say so plainly." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "aside-list",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "mailto:hello@elisemaren.studio",
								children: "hello@elisemaren.studio"
							}) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Hours" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Tuesday to Friday, CET" })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "New work" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Two projects a season" })] })
						]
					})]
				}), status === "sent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "success",
					role: "status",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "Received"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Noted. Thank you." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This preview keeps your note on the page only — nothing is emailed. On the live studio site it would land in the inbox. You can also write directly to hello@elisemaren.studio." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => {
								setValues(EMPTY);
								setErrors({});
								setStatus("idle");
							},
							children: "Write another"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: shake ? "form is-shaking" : "form",
					onSubmit,
					noValidate: true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: errors.name ? "field has-error" : "field",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "name",
									children: "Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "name",
									name: "name",
									autoComplete: "name",
									value: values.name,
									"aria-invalid": Boolean(errors.name),
									"aria-describedby": errors.name ? "name-error" : void 0,
									onChange: (event) => update("name", event.target.value)
								}),
								errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "field-error",
									id: "name-error",
									children: errors.name
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: errors.email ? "field has-error" : "field",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "email",
									children: "Email"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "email",
									name: "email",
									type: "email",
									autoComplete: "email",
									inputMode: "email",
									value: values.email,
									"aria-invalid": Boolean(errors.email),
									"aria-describedby": errors.email ? "email-error" : void 0,
									onChange: (event) => update("email", event.target.value)
								}),
								errors.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "field-error",
									id: "email-error",
									children: errors.email
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: errors.intent ? "field has-error" : "field",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "intent",
									children: "What do you need"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "select-wrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "intent",
										name: "intent",
										value: values.intent,
										"aria-invalid": Boolean(errors.intent),
										"aria-describedby": errors.intent ? "intent-error" : void 0,
										onChange: (event) => update("intent", event.target.value),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Select one"
										}), INTENTS.map((intent) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: intent,
											children: intent
										}, intent))]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
										size: 16,
										strokeWidth: 1.6,
										"aria-hidden": "true"
									})]
								}),
								errors.intent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "field-error",
									id: "intent-error",
									children: errors.intent
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: errors.message ? "field has-error" : "field",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "message",
									children: "Message"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "message",
									name: "message",
									rows: 5,
									value: values.message,
									"aria-invalid": Boolean(errors.message),
									"aria-describedby": errors.message ? "message-error" : void 0,
									onChange: (event) => update("message", event.target.value)
								}),
								errors.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "field-error",
									id: "message-error",
									children: errors.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "form-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "form-hint",
								children: "All fields required."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn btn-primary",
								type: "submit",
								disabled: status === "sending",
								children: status === "sending" ? "Sending" : "Send note"
							})]
						})
					]
				})]
			})]
		})
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "hero",
		"aria-labelledby": "hero-title",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wrap",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Portfolio · Lisbon · 2014—2026"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					id: "hero-title",
					className: "masthead",
					children: [
						"Elise",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"Maren"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hero-grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "deck",
						children: "Interfaces with the patience of a printed page."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "btn btn-primary",
							href: "#work",
							children: "Selected work"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "btn btn-ghost",
							href: "#contact",
							children: "Start a project"
						})]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "I design product systems, identities, and websites for small teams who care how a thing is made. The work is slow on purpose — measured, then built."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "hero-meta",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Based" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Lisbon, remote" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Practice" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Design & engineering" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Booking" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "avail",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "avail-dot",
								"aria-hidden": "true"
							}), "Spring 2027"]
						}) })] })
					]
				})
			]
		})
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "site-footer",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wrap",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "footer-grid",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "footer-label",
						children: "Studio"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "footer-name",
						children: [
							"Elise",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Maren"
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "footer-links",
						"aria-label": "Footer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "footer-label",
							children: "Index"
						}), NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: item.href,
							children: item.label
						}, item.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "footer-note",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "footer-label",
								children: "Colophon"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Set in Fraunces and Outfit. A single scrolling page, printed in the browser." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "mailto:hello@elisemaren.studio",
								children: "hello@elisemaren.studio"
							}) })
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "footer-bottom",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "© 2026 Elise Maren. All rights reserved." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#top",
					children: "Back to top"
				})]
			})]
		})
	});
}
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const nodes = NAV.map((item) => document.getElementById(item.id)).filter((node) => Boolean(node));
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible?.target.id) setActive(visible.target.id);
		}, {
			rootMargin: "-45% 0px -45% 0px",
			threshold: [
				.1,
				.25,
				.5
			]
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(min-width: 760px)");
		const onChange = () => {
			if (mq.matches) setOpen(false);
		};
		mq.addEventListener("change", onChange);
		return () => mq.removeEventListener("change", onChange);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "site-header",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "skip",
				href: "#work",
				children: "Skip to work"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "wrap header-bar",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "brand",
						href: "#top",
						children: "Elise Maren"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "nav-desktop",
						"aria-label": "Primary",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "nav-link",
							href: item.href,
							"aria-current": active === item.id ? "true" : void 0,
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "menu-btn",
						"aria-expanded": open,
						"aria-controls": "mobile-nav",
						onClick: () => setOpen((value) => !value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "icon-swap",
							"data-open": open ? "true" : "false",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
								className: "icon-open",
								size: 18,
								strokeWidth: 1.6
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
								className: "icon-close",
								size: 18,
								strokeWidth: 1.6
							})]
						}), open ? "Close" : "Menu"]
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				id: "mobile-nav",
				className: "nav-mobile wrap",
				"aria-label": "Primary",
				children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: item.href,
					onClick: () => setOpen(false),
					children: item.label
				}, item.id))
			}) : null
		]
	});
}
function SkillsSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		id: "skills",
		"aria-labelledby": "skills-title",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wrap",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "03 — Skills"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "skills-title",
					className: "section-title",
					children: "Three registers, one desk."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "section-note",
					children: "I don’t split design from build. These are the skills I actually use on a project, not a résumé grid."
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "skill-grid",
				children: SKILL_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: group.title }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: group.note }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "skill-list",
						children: group.items.map(([name, detail]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: detail })] }, name))
					})
				] }, group.title))
			})]
		})
	});
}
function WorkSection() {
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const visible = filter === "All" ? PROJECTS : PROJECTS.filter((project) => project.category === filter);
	const countLabel = `${String(visible.length).padStart(2, "0")} ${visible.length === 1 ? "work" : "works"}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section",
		id: "work",
		"aria-labelledby": "work-title",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wrap",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "01 — Work"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "work-title",
						className: "section-title",
						children: "Selected projects"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "section-note",
						children: "Hover a card to read the short version. On a phone, use Details."
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "work-tools",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "chips",
						role: "group",
						"aria-label": "Filter projects by category",
						children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: filter === item ? "chip is-on" : "chip",
							"aria-pressed": filter === item,
							onClick: () => {
								setFilter(item);
								setOpenId(null);
							},
							children: item
						}, item))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "count",
						"aria-live": "polite",
						children: countLabel
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: filter === "All" ? "work-grid is-featured" : "work-grid",
					children: visible.map((project) => {
						const open = openId === project.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: project.featured && filter === "All" ? "project-card is-feature" + (open ? " is-open" : "") : "project-card" + (open ? " is-open" : ""),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "project-media",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: project.image,
									alt: project.alt
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "project-reveal",
									id: `desc-${project.id}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: project.summary })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "project-meta",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "project-index",
										children: project.index
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: project.title }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "project-year",
										children: project.year
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "project-role",
										children: [
											project.category,
											" · ",
											project.role
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "details-btn",
										"aria-expanded": open,
										"aria-controls": `desc-${project.id}`,
										onClick: () => setOpenId(open ? null : project.id),
										children: open ? "Hide" : "Details"
									})
								]
							})]
						}, project.id);
					})
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkSection, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutSection, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillsSection, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactSection, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
