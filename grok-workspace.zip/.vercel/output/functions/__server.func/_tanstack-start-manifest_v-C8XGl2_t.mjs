//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C8XGl2_t.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CfkB3oRA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CfkB3oRA.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Cj2UIvuB.js"]
	}
} });
//#endregion
export { tsrStartManifest };
