import { NAV } from "@/data/site";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <p className="footer-label">Practice</p>
            <p className="footer-name">
              Md. Simon
              <br />
              Islam
            </p>
          </div>
          <nav className="footer-links" aria-label="Footer">
            <p className="footer-label">Index</p>
            {NAV.map((item) => (
              <a key={item.id} href={item.href}>
                {item.label}
              </a>
            ))}
          </nav>
          <div className="footer-note">
            <p className="footer-label">Colophon</p>
            <p>Set in Fraunces and Outfit. A research portfolio for work done in Bangladesh.</p>
            <p>
              <a href="mailto:sionick56@gmail.com">sionick56@gmail.com</a>
            </p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>© 2026 Md. Simon Islam.</p>
          <a href="#top">Back to top</a>
        </div>
      </div>
    </footer>
  );
}
