import { PAPERS, SCHOLAR } from "@/data/site";

function Authors({ text }: { text: string }) {
  const parts = text.split("Islam MS");
  return (
    <p>
      {parts.map((part, index) => (
        <span key={index}>
          {part}
          {index < parts.length - 1 ? <strong>Islam MS</strong> : null}
        </span>
      ))}
    </p>
  );
}

export function PapersSection() {
  return (
    <section className="section" id="papers" aria-labelledby="papers-title">
      <div className="wrap">
        <div className="section-head">
          <p className="kicker">02 — Papers</p>
          <div>
            <h2 id="papers-title" className="section-title">
              Nine papers, one dataset, two meetings.
            </h2>
            <p className="section-note">
              Google Scholar lists 91 citations, an h-index of 4, and an i10-index of 4.{" "}
              <a href={SCHOLAR}>Open the profile</a>.
            </p>
          </div>
        </div>
        <div className="paper-groups">
          {PAPERS.map((group) => (
            <div key={group.kind}>
              <h3>{group.kind}</h3>
              {group.items.map((paper) => (
                <article className="paper" key={paper.title}>
                  <p className="kicker">{paper.venue}</p>
                  <h4>
                    {paper.href ? (
                      <a href={paper.href}>{paper.title}</a>
                    ) : (
                      paper.title
                    )}
                  </h4>
                  <Authors text={paper.authors} />
                </article>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
