import { SCHOLAR } from "@/data/site";

export function Hero() {
  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="wrap">
        <p className="kicker">Entomology · Agricultural research · Bangladesh</p>
        <h1 id="hero-title" className="masthead">
          Md. Simon
          <br />
          Islam
        </h1>
        <div className="hero-grid">
          <div>
            <p className="deck">Eco-friendly protection for tea, from the plot to the estate.</p>
            <div className="hero-actions">
              <a className="btn btn-primary" href="#work">
                Selected work
              </a>
              <a className="btn btn-ghost" href="#contact">
                Get in touch
              </a>
            </div>
          </div>
          <p className="lede">
            Entomologist and agricultural researcher. Doctoral work on the tea red spider mite,
            and operational charge of crop protection on a large tea estate.
          </p>
        </div>
        <dl className="hero-meta">
          <div>
            <dt>Based</dt>
            <dd>Bangladesh</dd>
          </div>
          <div>
            <dt>Now</dt>
            <dd>Duncan Brothers</dd>
          </div>
          <div>
            <dt>Scholar</dt>
            <dd>
              <a href={SCHOLAR}>91 citations · h-index 4</a>
            </dd>
          </div>
        </dl>
      </div>
    </section>
  );
}
