import { useState } from "react";
import { FILTERS, PROJECTS, type Filter } from "@/data/site";

export function WorkSection() {
  const [filter, setFilter] = useState<Filter>("All");
  const [openId, setOpenId] = useState<string | null>(null);
  const visible =
    filter === "All" ? PROJECTS : PROJECTS.filter((project) => project.category === filter);
  const countLabel = `${String(visible.length).padStart(2, "0")} ${
    visible.length === 1 ? "work" : "works"
  }`;

  return (
    <section className="section" id="work" aria-labelledby="work-title">
      <div className="wrap">
        <div className="section-head">
          <p className="kicker">01 — Work</p>
          <div>
            <h2 id="work-title" className="section-title">
              Selected work
            </h2>
            <p className="section-note">
              Research, the estate, and the papers that came out of both. Hover a card, or use
              Details on a phone.
            </p>
          </div>
        </div>
        <div className="work-tools">
          <div className="chips" role="group" aria-label="Filter projects by category">
            {FILTERS.map((item) => (
              <button
                key={item}
                type="button"
                className={filter === item ? "chip is-on" : "chip"}
                aria-pressed={filter === item}
                onClick={() => {
                  setFilter(item);
                  setOpenId(null);
                }}
              >
                {item}
              </button>
            ))}
          </div>
          <p className="count" aria-live="polite">
            {countLabel}
          </p>
        </div>
        <div className={filter === "All" ? "work-grid is-featured" : "work-grid"}>
          {visible.map((project) => {
            const open = openId === project.id;
            return (
              <article
                key={project.id}
                className={
                  project.featured && filter === "All"
                    ? "project-card is-feature" + (open ? " is-open" : "")
                    : "project-card" + (open ? " is-open" : "")
                }
              >
                <div className="project-media">
                  <img
                    src={project.image}
                    alt={project.alt}
                    className={project.frame === "map" ? "frame-map" : undefined}
                  />
                  <div className="project-reveal" id={`desc-${project.id}`}>
                    <p>{project.summary}</p>
                  </div>
                </div>
                <div className="project-meta">
                  <span className="project-index">{project.index}</span>
                  <h3>{project.title}</h3>
                  <span className="project-year">{project.year}</span>
                  <p className="project-role">
                    {project.category} · {project.role}
                  </p>
                  <button
                    type="button"
                    className="details-btn"
                    aria-expanded={open}
                    aria-controls={`desc-${project.id}`}
                    onClick={() => setOpenId(open ? null : project.id)}
                  >
                    {open ? "Hide" : "Details"}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
