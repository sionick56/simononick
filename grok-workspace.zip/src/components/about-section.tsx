export function AboutSection() {
  return (
    <section className="section" id="about" aria-labelledby="about-title">
      <div className="wrap">
        <div className="section-head">
          <p className="kicker">03 — About</p>
          <h2 id="about-title" className="section-title">
            Research on the mite, and the estate that has to live with it.
          </h2>
        </div>
        <div className="about-grid">
          <p className="pull">
            Tea red spider mite, clone tolerance, and crop protection at the scale of a working
            garden.
          </p>
          <div>
            <div className="prose">
              <p>
                I am Md. Simon Islam, an entomologist and agricultural researcher in Bangladesh.
                My dissertation, in Crop Botany and Tea Production Technology at Sylhet
                Agricultural University, is on eco-friendly management of the tea red spider mite,{" "}
                <em>Oligonychus coffeae</em>.
              </p>
              <p>
                The dissertation was defended in November 2025 and approved by the Academic
                Council. Final approval at the University Syndicate is still pending, so the
                certificate has not been issued.
              </p>
              <p>
                Alongside the research I work in operations at Duncan Brothers (Bangladesh)
                Limited: field inspection, pest and disease monitoring, integrated pest management,
                and the records that keep a large estate intelligible.
              </p>
            </div>
            <dl className="facts">
              <div>
                <dt>Role</dt>
                <dd>Senior Assistant Manager, Operations</dd>
              </div>
              <div>
                <dt>Since</dt>
                <dd>March 2026 · Duncan Brothers</dd>
              </div>
              <div>
                <dt>Fellowship</dt>
                <dd>National Science and Technology Fellowship for the PhD</dd>
              </div>
            </dl>
          </div>
        </div>
        <div className="record">
          <div>
            <h3>Education</h3>
            <dl className="facts">
              <div>
                <dt>PhD track</dt>
                <dd>
                  Crop Botany and Tea Production Technology, Sylhet Agricultural University.
                  Defended November 2025.
                </dd>
              </div>
              <div>
                <dt>M.Sc.</dt>
                <dd>Entomology, Sylhet Agricultural University, 2019. CGPA 3.57.</dd>
              </div>
              <div>
                <dt>B.Sc.</dt>
                <dd>Agriculture (Hons.), Sylhet Agricultural University, 2017. CGPA 3.301.</dd>
              </div>
            </dl>
          </div>
          <div>
            <h3>Experience</h3>
            <dl className="facts">
              <div>
                <dt>2026—</dt>
                <dd>
                  Senior Assistant Manager, Operations, Duncan Brothers. More than 1,800 hectares
                  and a workforce exceeding 1,800.
                </dd>
              </div>
              <div>
                <dt>2019–26</dt>
                <dd>
                  Assistant Manager, Operations, Duncan Brothers. More than 1,200 hectares and a
                  workforce exceeding 1,000.
                </dd>
              </div>
              <div>
                <dt>Training</dt>
                <dd>
                  Professional Diploma in Tea Management, Bangladesh Tea Board. Also BTRI, CABI
                  Academy, FAO eLearning, and the University of Alberta’s Bug 101.
                </dd>
              </div>
            </dl>
          </div>
        </div>
        <div className="record">
          <div>
            <h3>References</h3>
            <dl className="facts">
              <div>
                <dt>Supervisor</dt>
                <dd>
                  Professor Dr. A. F. M. Saiful Islam, Sylhet Agricultural University.{" "}
                  <a href="mailto:afmsislam@gmail.com">afmsislam@gmail.com</a>
                  {" · "}
                  <a href="tel:+8801711978392">+880 1711 978392</a>
                </dd>
              </div>
              <div>
                <dt>Entomology</dt>
                <dd>
                  Professor Dr. Md. Abdul Maleque, Department of Entomology, Sylhet Agricultural
                  University. <a href="mailto:maleq.entom@sau.ac.bd">maleq.entom@sau.ac.bd</a>
                </dd>
              </div>
            </dl>
          </div>
          <div>
            <h3>Also prepared</h3>
            <div className="prose">
              <p>
                Drought and tea pest management at the Bangladesh Tea Research Institute. A talk
                on fertilizer application for Duncan Brothers. Highly Hazardous Pesticides, FAO
                eLearning Academy. Plant Protection and Integrated Pest Management, CABI Academy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
