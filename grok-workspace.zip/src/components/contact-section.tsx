import { useState, type FormEvent } from "react";
import { ChevronDown } from "lucide-react";
import { INTENTS } from "@/data/site";

type Fields = {
  name: string;
  email: string;
  intent: string;
  message: string;
};

type Errors = Partial<Record<keyof Fields, string>>;

const EMPTY: Fields = { name: "", email: "", intent: "", message: "" };

function validate(values: Fields): Errors {
  const errors: Errors = {};
  if (values.name.trim().length < 2) errors.name = "Please add your name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) {
    errors.email = "That email doesn’t look right.";
  }
  if (!values.intent) errors.intent = "Choose what you need.";
  if (values.message.trim().length < 20) {
    errors.message = "Give me a sentence or two — at least 20 characters.";
  }
  return errors;
}

export function ContactSection() {
  const [values, setValues] = useState<Fields>(EMPTY);
  const [errors, setErrors] = useState<Errors>({});
  const [shake, setShake] = useState(false);
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");

  function update<K extends keyof Fields>(key: K, value: Fields[K]) {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
  }

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const next = validate(values);
    setErrors(next);
    if (Object.keys(next).length > 0) {
      setShake(true);
      window.setTimeout(() => setShake(false), 250);
      const first = (Object.keys(next) as Array<keyof Fields>)[0];
      const node = document.getElementById(first);
      if (node instanceof HTMLElement) node.focus();
      return;
    }
    setStatus("sending");
    window.setTimeout(() => setStatus("sent"), 600);
  }

  return (
    <section className="section" id="contact" aria-labelledby="contact-title">
      <div className="wrap">
        <div className="section-head">
          <p className="kicker">05 — Contact</p>
          <h2 id="contact-title" className="section-title">
            Write about the work.
          </h2>
        </div>
        <div className="contact-grid">
          <div className="contact-aside">
            <p>
              Research, the estate, or a talk. This form keeps the note in the browser only — for
              a message that arrives, use the email or phone.
            </p>
            <dl className="aside-list">
              <div>
                <dt>Email</dt>
                <dd>
                  <a href="mailto:sionick56@gmail.com">sionick56@gmail.com</a>
                </dd>
              </div>
              <div>
                <dt>Phone</dt>
                <dd>
                  <a href="tel:+8801515273761">+880 1515 273761</a>
                  <br />
                  <a href="tel:+8801303370607">+880 1303 370607</a>
                </dd>
              </div>
              <div>
                <dt>Based</dt>
                <dd>Bangladesh</dd>
              </div>
            </dl>
          </div>
          {status === "sent" ? (
            <div className="success" role="status">
              <p className="kicker">Received</p>
              <h3>Noted. Thank you.</h3>
              <p>
                Nothing was emailed. The note stays on this page. Write to sionick56@gmail.com, or
                call +880 1515 273761.
              </p>
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => {
                  setValues(EMPTY);
                  setErrors({});
                  setStatus("idle");
                }}
              >
                Write another
              </button>
            </div>
          ) : (
            <form
              className={shake ? "form is-shaking" : "form"}
              onSubmit={onSubmit}
              noValidate
            >
              <div className={errors.name ? "field has-error" : "field"}>
                <label htmlFor="name">Name</label>
                <input
                  id="name"
                  name="name"
                  autoComplete="name"
                  value={values.name}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? "name-error" : undefined}
                  onChange={(event) => update("name", event.target.value)}
                />
                {errors.name ? (
                  <p className="field-error" id="name-error">
                    {errors.name}
                  </p>
                ) : null}
              </div>
              <div className={errors.email ? "field has-error" : "field"}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  inputMode="email"
                  value={values.email}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? "email-error" : undefined}
                  onChange={(event) => update("email", event.target.value)}
                />
                {errors.email ? (
                  <p className="field-error" id="email-error">
                    {errors.email}
                  </p>
                ) : null}
              </div>
              <div className={errors.intent ? "field has-error" : "field"}>
                <label htmlFor="intent">What do you need</label>
                <div className="select-wrap">
                  <select
                    id="intent"
                    name="intent"
                    value={values.intent}
                    aria-invalid={Boolean(errors.intent)}
                    aria-describedby={errors.intent ? "intent-error" : undefined}
                    onChange={(event) => update("intent", event.target.value)}
                  >
                    <option value="">Select one</option>
                    {INTENTS.map((intent) => (
                      <option key={intent} value={intent}>
                        {intent}
                      </option>
                    ))}
                  </select>
                  <ChevronDown size={16} strokeWidth={1.6} aria-hidden="true" />
                </div>
                {errors.intent ? (
                  <p className="field-error" id="intent-error">
                    {errors.intent}
                  </p>
                ) : null}
              </div>
              <div className={errors.message ? "field has-error" : "field"}>
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows={5}
                  value={values.message}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? "message-error" : undefined}
                  onChange={(event) => update("message", event.target.value)}
                />
                {errors.message ? (
                  <p className="field-error" id="message-error">
                    {errors.message}
                  </p>
                ) : null}
              </div>
              <div className="form-row">
                <p className="form-hint">All fields required.</p>
                <button className="btn btn-primary" type="submit" disabled={status === "sending"}>
                  {status === "sending" ? "Sending" : "Send note"}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
