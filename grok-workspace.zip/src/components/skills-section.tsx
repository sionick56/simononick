import { SKILL_GROUPS } from "@/data/site";

export function SkillsSection() {
  return (
    <section className="section" id="skills" aria-labelledby="skills-title">
      <div className="wrap">
        <div className="section-head">
          <p className="kicker">04 — Skills</p>
          <div>
            <h2 id="skills-title" className="section-title">
              What the work actually uses.
            </h2>
            <p className="section-note">
              Pest ecology, the analysis around it, and the operational habits of a tea estate.
            </p>
          </div>
        </div>
        <div className="skill-grid">
          {SKILL_GROUPS.map((group) => (
            <div key={group.title}>
              <h3>{group.title}</h3>
              <p>{group.note}</p>
              <ul className="skill-list">
                {group.items.map(([name, detail]) => (
                  <li key={name}>
                    <strong>{name}</strong>
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
