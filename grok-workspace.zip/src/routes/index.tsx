import { createFileRoute } from "@tanstack/react-router";
import { AboutSection } from "@/components/about-section";
import { ContactSection } from "@/components/contact-section";
import { Hero } from "@/components/hero";
import { PapersSection } from "@/components/papers-section";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { SkillsSection } from "@/components/skills-section";
import { WorkSection } from "@/components/work-section";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div id="top">
      <SiteHeader />
      <main>
        <Hero />
        <WorkSection />
        <PapersSection />
        <AboutSection />
        <SkillsSection />
        <ContactSection />
      </main>
      <SiteFooter />
    </div>
  );
}
