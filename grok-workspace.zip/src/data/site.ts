export const NAV = [
  { href: "#work", id: "work", label: "Work" },
  { href: "#papers", id: "papers", label: "Papers" },
  { href: "#about", id: "about", label: "About" },
  { href: "#skills", id: "skills", label: "Skills" },
  { href: "#contact", id: "contact", label: "Contact" },
] as const;

export const SCHOLAR = "https://scholar.google.com/citations?user=3RR3DkAAAAAJ&hl=en";

export const FILTERS = ["All", "Research", "Field", "Writing"] as const;
export type Filter = (typeof FILTERS)[number];

export type Project = {
  id: string;
  index: string;
  title: string;
  category: Exclude<Filter, "All">;
  year: string;
  role: string;
  summary: string;
  image: string;
  alt: string;
  featured?: boolean;
  frame?: "map";
};

export const PROJECTS: Project[] = [
  {
    id: "mite",
    index: "01",
    title: "Tea red spider mite",
    category: "Research",
    year: "2025",
    role: "Doctoral dissertation",
    summary:
      "Eco-friendly management of Oligonychus coffeae for sustainable tea production: pest occurrence, clone responses, and field and screen-house trials.",
    image: "/work/flush.jpg",
    alt: "A fresh tea flush of two leaves and a bud",
    featured: true,
  },
  {
    id: "estate",
    index: "02",
    title: "Duncan Brothers",
    category: "Field",
    year: "2026",
    role: "Estate operations",
    summary:
      "Senior Assistant Manager, Operations. Crop care on more than 1,800 hectares: planting, pruning, plucking, pest and disease monitoring, and integrated pest management.",
    image: "/work/estate.jpg",
    alt: "Mist over rows of tea bushes at dawn",
  },
  {
    id: "pests",
    index: "03",
    title: "Pests of the tea agroecosystem",
    category: "Writing",
    year: "2025",
    role: "Agroforestry Systems",
    summary:
      "Documentation of major tea pests and the spectrum of pesticide use across estates in north-eastern Bangladesh. A Q1 paper in Agroforestry Systems.",
    image: "/work/survey.jpg",
    alt: "Map of tea-estate survey locations in Sylhet, Moulvibazar, and Habiganj",
    frame: "map",
  },
  {
    id: "drought",
    index: "04",
    title: "Drought and liquor quality",
    category: "Research",
    year: "2025",
    role: "Tea clones",
    summary:
      "Morphology and quality of drought-tolerant tea clones, alongside a review of how drought stress changes leaf productivity and liquor.",
    image: "/work/liquor.jpg",
    alt: "White bowls of tea liquor lined up for tasting",
  },
  {
    id: "arthropods",
    index: "05",
    title: "Arthropod diversity",
    category: "Writing",
    year: "2025",
    role: "Occurrence dataset",
    summary:
      "An open record of arthropods in the tea ecosystem of north-eastern Bangladesh, published with Sylhet Agricultural University.",
    image: "/work/field.jpg",
    alt: "A field notebook and a fern on moss",
  },
];

export const PAPERS = [
  {
    kind: "International",
    items: [
      {
        title:
          "Documentation of major pests and spectrum of pesticide usage for tea agroecosystems in Bangladesh",
        authors:
          "Maleque MA, Islam AFMS, Ahmod MM, Islam MS, Hasan R, Jewel KN, M Saifullah and Ishii HR",
        venue: "Agroforestry Systems, 99:188 · 2025",
        href: "https://doi.org/10.1007/s10457-025-01295-5",
      },
      {
        title: "Morphological and quality assessment of drought-tolerant tea clones in Bangladesh",
        authors: "Hasan R, Islam AFMS, Maleque MA, Islam MS",
        venue: "Asian Journal of Soil Science and Plant Nutrition, 11(4): 287–298 · 2025",
        href: "https://doi.org/10.9734/ajsspn/2025/v11i4602",
      },
      {
        title: "Effect of drought stress on leaf productivity and liquor quality of tea: a review",
        authors: "Hasan R, Islam AFMS, Maleque MA, Islam MS and Rahman MM",
        venue: "Asian Journal of Soil Science and Plant Nutrition, 9(4): 1–10 · 2023",
        href: "https://doi.org/10.9734/ajsspn/2023/v9i4187",
      },
    ],
  },
  {
    kind: "National",
    items: [
      {
        title:
          "Major pests of tea and their integrated management with a focus on tea red spider mite: a review",
        authors: "Islam MS, Islam AFMS, Hasan R, Tanni AS, Kobra KT and Maleque MA",
        venue: "Bangladesh Journal of Entomology, 31(1): 1–20 · 2023",
      },
      {
        title:
          "Tolerance of tea clones against the red spider mite (Oligonychus coffeae) in prevailing weather parameters",
        authors: "Khan IS, Islam MS, Nandi M, Mondal MF and Maleque MA",
        venue: "Bangladesh Journal of Entomology, 32(1): 13–28 · 2024",
        href: "https://doi.org/10.63759/bje.32.1.2",
      },
      {
        title:
          "Management of brinjal shoot and fruit borer (Leucinodes orbonalis Guen.) using selected bio-rational insecticides",
        authors: "Islam MS, Choudhury MAR, Maleque MA, Mondal M, Hassan K and Khan AU",
        venue: "Fundamental and Applied Agriculture, 4(4): 1025–1031 · 2019",
        href: "https://doi.org/10.5455/faa.55331",
      },
      {
        title:
          "Development of effective management practices against pod borer (Helicoverpa armigera Hubner) infesting chickpea",
        authors: "Alam S, Nandi M, Asad-Ud-Doullah M, Islam MS, Maleque MA",
        venue: "Bangladesh Journal of Entomology, 32(1): 29–43 · 2024",
        href: "https://doi.org/10.63759/bje.32.1.3",
      },
      {
        title: "Varietal performances of country beans against insect pests in bean agro-ecosystem",
        authors: "Khan AU, Choudhury MAR, Ferdous J, Islam MS and Rahaman SM",
        venue: "Bangladesh Journal of Entomology, 29(1): 27–37 · 2019",
      },
      {
        title: "Abundance and fluctuation patterns of insect pests in country bean",
        authors: "Khan AU, Choudhury MAR, Islam MS and Maleque MA",
        venue: "Journal of Sylhet Agricultural University, 5(2): 167–172 · 2018",
      },
    ],
  },
  {
    kind: "Data and talks",
    items: [
      {
        title: "Arthropod diversity in the tea ecosystem of north-eastern Bangladesh",
        authors: "Maleque MA, Ahmod MM, Islam MS and Islam AFMS",
        venue: "Occurrence dataset, Sylhet Agricultural University · 2025",
        href: "https://doi.org/10.15468/a5v9hh",
      },
      {
        title: "Plants for Food, Health and Resilient Environment",
        authors: "Islam MS",
        venue: "Oral paper, 2nd Annual Conference, Cox’s Bazar · 23–24 January 2023",
      },
      {
        title: "Development of bio-rational based management techniques against tea red spider mite",
        authors: "Islam MS, Maleque MA, Hasan R and Saiful Islam AFM",
        venue:
          "Poster, International Conference on Advanced Agricultural Research, Sylhet · 23–24 May 2024",
      },
    ],
  },
] as const;

export const SKILL_GROUPS = [
  {
    title: "Pests and plants",
    note: "The organisms, and how the crop answers them.",
    items: [
      ["Entomology", "Insects, mites, and the damage they leave"],
      ["Tea pests", "Monitoring red spider mite, mosquito bug, and disease"],
      ["Integrated pest management", "Prevention first, then a measured response"],
      ["Host response", "Clone tolerance and plant–arthropod interaction"],
    ],
  },
  {
    title: "Methods",
    note: "How the questions get answered.",
    items: [
      ["Field trials", "Estate, plot, and screen-house experiments"],
      ["R", "Research data analysis"],
      ["ArcGIS", "Study-site mapping"],
      ["Writing", "Papers, reviews, and technical reports"],
    ],
  },
  {
    title: "Practice",
    note: "The estate, not only the experiment.",
    items: [
      ["Crop operations", "Planting, pruning, plucking, irrigation"],
      ["Tea tasting", "Liquor as part of quality, not an afterthought"],
      ["Coordination", "Field teams, training, and labour planning"],
      ["Records", "Pest status, production, and development reports"],
    ],
  },
] as const;

export const INTENTS = [
  "Research collaboration",
  "Field or estate",
  "A talk",
  "Something else",
] as const;
